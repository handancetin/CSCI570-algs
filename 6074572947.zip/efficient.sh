#!/bin/sh
python3 efficient_3.py input.txt output.txt
    