#!/bin/sh
python3 basic_3.py input.txt output.txt